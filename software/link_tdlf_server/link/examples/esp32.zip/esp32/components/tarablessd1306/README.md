<!---
 Copyright (c) 2017 Tara Keeling
 
 This software is released under the MIT License.
 https://opensource.org/licenses/MIT
-->

# SSD1306 Component for the ESP32 and ESP-IDF SDK

## About:  
This is a simple component for the SSD1306 display.  
It supports multiple display sizes on both i2c and spi interfaces.  
  
Check out the wiki where most of the relevant information is.

***Examples:*** https://github.com/TaraHoleInIt/tarablessd1306_examples
